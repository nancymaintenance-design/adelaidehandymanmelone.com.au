# MEL ONE Visual Refresh Design

## Goal

Transform the existing MEL ONE Adelaide carpentry and joinery site into a coherent, premium craft-led experience while preserving the existing homepage hero photograph unchanged.

## Brand and audience

The public brand is **MEL ONE**. The audience is Adelaide homeowners, property managers, and builders who need confident, practical timber work. All public-facing company-name references, the wordmark, page titles, structured data, and favicon must use MEL ONE; no `Ellis Services Group` or `ESG` reference may remain in the generated website.

## Visual system

Use a workshop editorial direction: deep eucalypt green for authority, pale timber-linen surfaces for warmth, and restrained copper accents for action and wayfinding. Typography should combine a high-character editorial display face stack with a highly legible sans-serif interface stack. Borders, grid lines, and subtle grain textures should suggest measured joinery rather than generic construction branding.

The homepage image remains byte-for-byte unchanged. Its existing full-bleed treatment remains, with only adjacent type, navigation, and controls restyled for better contrast and hierarchy.

## Symbol artwork

Create a small set of original, transparent-background raster symbols for use across the site: a mortise-and-tenon joint, a framing angle/measure mark, a timber grain/annual ring, and a restoration repair mark. Artwork is monochrome or two-tone in the MEL ONE palette, contains no text, no logos, no watermark, and is used as compact decorative/section-identification media rather than a replacement for the brand wordmark.

## Page and component changes

- Add a stable visual token layer and improve page-wide body, header, menu, buttons, focus styles, cards, form controls, details accordions, section dividers, footer, and responsive spacing.
- Establish one reusable icon treatment for service listings, process steps, FAQ, and calls to action; use CSS masks/background images from the supplied symbol artwork where applicable.
- Update the site builder so generated HTML has a MEL ONE wordmark, MEL ONE favicon, and a brand-consistent decorative asset set. The builder must copy new assets to both preview and docs builds.
- Retain all existing route structure, content subjects, contact details, and homepage hero image. Do not change functional navigation or form submission behavior.

## Accessibility and responsive requirements

- Keep semantic navigation, heading order, links, buttons, and form labels intact.
- Ensure keyboard focus is visible, controls have clear hover/focus/active states, and text/interactive contrast meets WCAG AA.
- Preserve the mobile navigation behavior and make all decorative symbols non-essential to comprehension.
- Validate wide desktop, compact mobile, FAQ expanded state, form fields, and service-card interactions.

## Validation

Run the project build and integrity checker. Inspect the generated homepage, services landing page, about page, contact page, and a service detail page in a browser. Confirm the existing homepage hero source was not modified, brand terms are fully migrated in generated output, and all generated symbol assets resolve from `/assets/`.
