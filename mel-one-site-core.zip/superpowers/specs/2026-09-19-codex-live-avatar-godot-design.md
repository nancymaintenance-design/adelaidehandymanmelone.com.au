# Codex Live Avatar Godot 4 影视级风格化角色设计

## 目标

将现有 DOAXVV 捕获角色整理为可在 Godot 4.x 桌面端实时运行的影视级风格化数字人。保留现有角色辨识度、身体比例、服装与头发，优先复用已经提取的网格和权重信息，不批量生成替代模型。

最终角色需要支持标准人形动画、面部表情、实时嘴型、眼神控制、换装、头发与服装的次级运动，以及供 Codex Live Avatar Runtime 调用的控制接口。

## 当前基线

- 完整角色、服装和短发已经组合。
- 当前模型约 55,010 个顶点、65,297 个三角面、30 个 glTF Mesh。
- `DOAXVV_character_with_hair_fixed.glb` 保留一套 576 关节捕获骨架，适合验证完整结构，不适合作为正式 Humanoid 骨架。
- `DOAXVV_character_with_hair_sdk128.glb` 使用四个 skin，每个 skin 不超过 128 个关节，适合验证 SDK 加载，不满足最终单骨架换装要求。
- 当前 GLB 有一个临时材质，没有嵌入纹理、动画或 Morph Target。
- 真正的短发网格为绘制号 306/307；307 是与身体一致的模型局部坐标版本。

## 最终资产结构

```text
LiveAvatar
├─ Skeleton
│  ├─ Humanoid body bones
│  ├─ Finger bones
│  ├─ Eye bones
│  ├─ Jaw bone
│  ├─ Hair physics bones
│  └─ Outfit physics bones
├─ Body
├─ Head
│  ├─ Face
│  ├─ Eyes
│  ├─ Teeth
│  └─ Tongue
├─ Hair
├─ Outfit
├─ Accessories
├─ Facial BlendShapes
├─ Materials
└─ Animation Library
```

身体、服装、头发和饰品保持独立 Mesh，但共享一套标准 Humanoid 骨架、统一 Rest Pose、比例和骨骼名称。面部主要通过 BlendShape 控制；眼球、下颌和头部允许使用骨骼控制。

## 制作管线

```text
现有捕获资产
→ 网格分类与清理
→ 恢复纹理和透明通道
→ 脸部及关节拓扑修整
→ 标准 Humanoid 骨架
→ 身体、服装、头发重新蒙皮
→ ARKit 与 Viseme BlendShape
→ GLB 导出
→ Godot 导入
→ AnimationTree 与控制接口
```

## 现有成果复用原则

- 现有身体、脸、服装和头发作为唯一几何基线。
- 不进行全身重新拓扑；只修正影响近景质量、表情或蒙皮的局部区域。
- 保留原始网格、UV、法线和部件边界，采用非破坏修改并保留源文件。
- 每个阶段只保留源文件、工作文件和通过验证的交付候选。
- 捕获骨架用于推断姿态和权重，不继续修补为正式骨架。
- 仅在缺少纹理、部件、表情参考或标准姿态时重新启动游戏捕获。

## 精修优先级

1. 眼睑、眼球、嘴唇、口腔和脸部轮廓。
2. 发际线、刘海、发梢透明和穿模。
3. 肩、肘、手指、髋、膝关节变形。
4. 服装边缘、厚度、身体穿透和披挂部件。
5. 远景不可见细节暂不增加。

## Godot 运行结构

```text
LiveAvatar
├─ CharacterRoot
│  ├─ Skeleton3D
│  ├─ BodyMeshes
│  ├─ OutfitMeshes
│  ├─ HairMeshes
│  ├─ BoneAttachments
│  ├─ AnimationPlayer
│  ├─ AnimationTree
│  └─ AvatarController
├─ FacialController
├─ LookAtController
├─ LipSyncController
└─ SecondaryMotionController
```

首批运行接口：

```text
set_state(IDLE | LISTENING | THINKING | SPEAKING)
set_expression(name, weight)
set_blendshape(name, weight)
set_viseme(name, weight)
set_look_target(x, y, z)
play_gesture(name)
interrupt()
```

## 材质与导出约束

- 最终交换格式为 GLB。
- Blender 导出时只导出 Deform Bones。
- 每个顶点最多保留四个有效骨骼影响并归一化。
- 使用 Godot 可识别的 PBR 通道：Base Color、Normal、Roughness、Metallic 和 Alpha。
- 头发使用透明通道与合适的双面策略；皮肤、眼睛和头发分别使用独立材质。
- Blender 工程为 Source File，GLB 与 Godot 场景为 Runtime File。

## 验证关卡

### Blender 资产验证

- 单一标准 Humanoid 骨架。
- 网格模块完整，权重总和正常。
- 无未绑定顶点、重复骨骼和异常缩放。
- T Pose、抬臂、屈膝、转头时无明显错误变形。

### GLB 往返验证

- GLB 能重新导入 Blender。
- 骨架、材质、纹理、BlendShape 和动画数量一致。
- 角色比例、朝向和外观不变。

### Godot 导入验证

- 正确生成 Skeleton3D、Mesh、Skin 和材质。
- 身体、服装和头发共用同一骨架。
- T Pose、抬臂、屈膝、转头、眨眼和张嘴正常。

### 运行验证

- IDLE、LISTENING、THINKING 和 SPEAKING 可以连续切换。
- 表情、嘴型、眼神和身体动画可以叠加。
- 连续运行 30 分钟无崩溃、持续内存增长或状态异常。
- 桌面端目标为 1080p 60 FPS，最低不低于 30 FPS。

## 异常处理

- 缺失纹理或部件时只补捕缺失资源。
- 权重转移失败时只修正对应网格区域。
- Godot 材质与 Blender 不一致时使用 Godot 覆盖材质，不返工几何。
- 面部、物理和 API 工作不阻塞基础角色导入；每一阶段保留可运行候选。

## 首阶段完成条件

- 原始纹理捕获并完成角色主要 PBR 材质基线。
- 网格整理为 Body、Head、Eyes、Hair、Outfit 和 Accessory。
- 完成脸部、头发和主要关节的第一轮修整。
- 建立单一标准 Humanoid 骨架并重新蒙皮。
- 导出并在 Godot 4.x 中验证首个单骨架 GLB。

