# MEL ONE Gold Standard Visual Redesign

## Objective

Rework the existing local MEL ONE candidate into a high-impact Adelaide household-maintenance website while retaining the approved content contract, ethical SEO output and local-only operating boundary.

## Audience and job

The primary audience is an Adelaide homeowner with a list of household jobs who needs a fast, clear way to call or begin an enquiry. The site’s single job is to turn that moment into a call or a well-scoped enquiry.

## Visual direction

**Name:** Gold Standard Home Care.

The signature device is a gold roof-line that enters in the hero and becomes a scrolling path through services, process and final conversion. It is an original brand device derived from MEL ONE’s crown-and-home mark—not a generic gradient or tradie template.

Tokens:

- Obsidian: `#111714` for depth and the hero field.
- Workbench black: `#202823` for surfaces.
- Crown gold: `#F7B733` for action and the roof-line.
- Ember orange: `#E9642B` for urgent emphasis.
- Eucalyptus: `#718576` for quiet structural copy.
- Limestone: `#F3EFE5` for reading surfaces.

Typography uses an expressive display serif for headlines, a plain sans-serif for customer-facing copy, and a compact mono utility style only for labels, process markers and service metadata. CSS system fallbacks must preserve usable rendering without remote font requests.

## Experience architecture

- The home hero combines short copy, actual user-authorized MEL ONE logo and concept image with an oversized gold route. It must expose Call and Start an enquiry above the fold.
- The service section is a tactile task wall: all nine approved categories have a distinct icon, service cue and direct detail route; it is not a uniform nine-card grid.
- The process is framed as a fast, three-step scope conversation, with high-contrast interaction points rather than fake proof or invented performance claims.
- Editorial content remains semantic and readable but uses a dense visual card system with context labels, date and service links.
- A site-wide mobile dock continues to offer Call and Start an enquiry. Keyboard focus, reduced motion and text contrast are first-class requirements.

## Content and compliance boundaries

- Continue to render only `src/content-pack/mel-one-site-content.json` as the public content source.
- Retain only confirmed MEL ONE identity, email, phone and address.
- Do not publish reviews, ratings, insurance, licences, prices, results, project counts or claims of immediate availability.
- Plumbing and gas must remain absent. Restricted work remains enquiry-only, with case-by-case specialist coordination language.
- Do not make network calls, persist form data, deploy or modify production services.

## Technical constraints and acceptance

- Keep the static Node generator and existing local preview at `http://127.0.0.1:5173`.
- Maintain 24 generated pages, valid schemas, `robots.txt`, sitemap and `llms.txt`.
- Replace legacy visual context in `DESIGN.md` with this token and behavior system, then preserve it as the cross-page source of truth.
- Add browser-verifiable tests for the high-impact hero, nine-category task wall and mobile dock without weakening current contact, crawl or claim guards.
- Use only local assets: the authorized logo and generated concept artwork, plus original CSS/SVG decorations.
