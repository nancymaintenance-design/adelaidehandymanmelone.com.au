# MEL ONE Local Website Candidate — Design Specification

## Purpose

Build an original, local-only MEL ONE website candidate for Adelaide household-maintenance enquiries. The primary visitor action is a phone call or a clear quote enquiry; no deployment, external submission, analytics connection, or email delivery is in scope.

## Verified public inputs

- Brand: MEL ONE.
- Phone: 0416 614 281.
- Email: admin@melonemaintenance.com.au.
- Contact address: 63 Pirie St, Adelaide SA 5000.
- Logo: `C:/Users/UFTR/Desktop/DATA/MEL ONE.png`, supplied and authorized by the user.

All historical claims about licence, insurance, years trading, projects, pricing, ratings, reviews, guarantees, service availability, team and third-party partnerships are pending. The candidate must not publish them or emit them in structured data.

## Service policy

The content model retains the nine-category operating taxonomy for future approval. Regulated or evidence-dependent categories remain `draft`/`noindex` and must not offer booking, fixed quotes, or unsupported capability claims. The public frontstage displays only content approved in the local fact ledger. No fabricated review, rating, customer quotation, case study, award or external endorsement is permitted.

## Public route model

- `/`: promise, quote/call actions, approved service choices, process, editorial entry, FAQ and final contact.
- `/services/` and service detail routes: unique visitor intent, scope, exclusions, related reading and enquiry action.
- `/how-it-works/`, `/service-areas/`, `/news/`, news details, `/guides/`, guide details, `/faq/`, `/about/`, `/contact/`, `/privacy/`, `/404.html`.
- `/admin/`: local-only content management for services, news, guides, FAQs, assets/ALT and site facts. It must state that changes are local-browser data only.

## Editorial and AI discovery

News and guides are original, useful, dated HTML articles using `article`, `header`, `section`, `h2` and related-service links. They may explain household-maintenance decisions but cannot impersonate current news, publish unverified MEL ONE claims, or be written merely to manipulate AI systems.

Implement unique metadata, canonicals, sitemap, robots, `llms.txt`, semantic HTML and JSON-LD derived from matching visible content. Supported types are WebSite, Organization/LocalBusiness, Service, BreadcrumbList, Article and FAQPage when the visible source qualifies. Do not use Review or AggregateRating markup. `llms.txt` is an index, not evidence of AI crawling or ranking.

## Experience and visual direction

Use the supplied crown-and-roof logo as the identity anchor. The visual system is **Adelaide Home Field Notes**: charcoal ink, warm limestone, muted eucalyptus, and the logo's gold/orange reserved for actions and operational markers. Use a generated conceptual visual family only where it cannot be mistaken for MEL ONE staff, projects or customers. Desktop and 390px layouts must preserve the call and quote actions in the first viewport; keyboard focus and reduced-motion behavior are required.

## Enquiry behavior

The local candidate shows a quote form with job details, suburb/postcode, preferred timing, contact preference, phone/email and optional photo UI. Local preview must not transmit data. If a local form simulation is included, it must visibly state that it is a demo and preserve data only in browser-local storage. A production upload pipeline is out of scope until retention, MIME/size validation, storage and privacy policy are approved.

## Non-goals

No deployment, DNS, Google Business Profile edits, Search Console submission, analytics connection, email sending, third-party review scraping/republication, paid API usage, fake reviews, hidden text, hidden keywords or unsupported structured data.
