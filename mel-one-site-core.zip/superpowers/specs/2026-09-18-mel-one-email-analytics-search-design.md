# MEL ONE Email, Analytics and Search Verification Design

## Goal

Enable MEL ONE to receive website enquiries by email, measure website traffic in GA4, and verify the production domain in Google Search Console without exposing credentials in browser code or GitHub.

## Scope

- The existing Vercel function at `api/contact.js` sends each validated contact enquiry to `handymanfelix.au2026@outlook.com` through Resend.
- Resend credentials live only in Vercel Production environment variables: `RESEND_API_KEY` and `RESEND_FROM_EMAIL`.
- GA4 loads only when a valid `G-...` Measurement ID is supplied as `GA4_MEASUREMENT_ID`; the ID is public but is stored as an environment variable to keep build configuration in one place.
- Search Console verification loads only when `GSC_VERIFICATION_TOKEN` is supplied. The generated document head emits one `google-site-verification` meta tag.
- The property to verify is `https://adelaidecarpentryhub.com.au/`. The submitted sitemap is `https://adelaidecarpentryhub.com.au/sitemap.xml`.

## Architecture

The static-site build reads only public build-time configuration and writes the GA4 loader and Search Console meta tag to every generated page. The server-side contact function reads Resend credentials at request time and submits a structured email to Resend; no secret is present in source, generated HTML, or GitHub.

Vercel hosts both the generated `docs/` output and the serverless `/api/contact` route. The Resend domain and the Search Console property are verified in their respective provider accounts, while Vercel is the single deployment environment for runtime configuration.

## Data Flow

1. A visitor submits name, phone, email, and message on `/contact/`.
2. Browser JavaScript POSTs JSON to `/api/contact`.
3. The Vercel function validates the request and calls the Resend email API using `RESEND_API_KEY`.
4. Resend sends a MEL ONE enquiry email to the Outlook inbox and applies the visitor email as Reply-To.
5. Every page includes GA4 only after `GA4_MEASUREMENT_ID` is set and includes the Search Console meta tag only after `GSC_VERIFICATION_TOKEN` is set.

## Required Account-Side Values

The following values cannot be invented or derived by the site and must be created in the owner’s accounts:

- A Resend `re_...` API key with Sending access.
- A verified Resend sending domain, `adelaidecarpentryhub.com.au`, allowing `MEL ONE <enquiries@adelaidecarpentryhub.com.au>`.
- A GA4 web data stream Measurement ID in the form `G-XXXXXXXXXX`.
- A Google Search Console HTML verification token for the production URL-prefix property.

## Error Handling and Verification

- Contact submissions with missing, malformed, oversize, or honeypot values return a safe 400 response.
- Missing Resend configuration returns a safe error without exposing secret values.
- Resend rejection returns a generic 502 response and Vercel logs the provider response for diagnosis.
- The build must pass existing integrity checks and regression tests must verify conditional GA4 and GSC output.
- Production verification consists of: a successful test enquiry visible in Resend and received in Outlook, a GA4 Realtime visit, and a verified GSC property with the sitemap accepted.

## Constraints

- Preserve the homepage cover image and existing MEL ONE visual direction.
- Never commit or display Resend keys, Google account credentials, or verification tokens in GitHub.
- Use the production domain `https://adelaidecarpentryhub.com.au/` consistently.
