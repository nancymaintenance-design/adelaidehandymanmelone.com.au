# MEL ONE Email, Analytics and Search Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver Resend-backed contact emails, GA4 analytics, and Google Search Console verification for the MEL ONE production website.

**Architecture:** `api/contact.js` remains the server-side Resend boundary. `build.mjs` conditionally emits GA4 and Google Search Console head markup based on public build configuration. Vercel stores all runtime and build configuration; provider accounts retain ownership of API keys and verification tokens.

**Tech Stack:** Node.js 24, Vercel Serverless Functions, Resend REST API, Google Analytics 4, Google Search Console, static HTML build.

**Spec:** `docs/superpowers/specs/2026-09-18-mel-one-email-analytics-search-design.md`

## Global Constraints

- Preserve the homepage cover image and MEL ONE visual direction.
- Never commit or display `RESEND_API_KEY`, Google credentials, or verification tokens.
- Use `https://adelaidecarpentryhub.com.au/` as the production domain.
- Use `handymanfelix.au2026@outlook.com` as the contact-enquiry recipient.
- Deploy only after tests and the existing integrity checker pass.

---

### Task 1: Make analytics and GSC output build-configurable

**Files:**
- Modify: `build.mjs`
- Modify: `.env.example`
- Modify: `test/contact-api.test.cjs`

**Interfaces:**
- Consumes: `GA4_MEASUREMENT_ID` formatted as `G-XXXXXXXXXX`; `GSC_VERIFICATION_TOKEN` from the Google Search Console HTML-tag workflow.
- Produces: a GA4 loader and one `google-site-verification` tag in generated documents only when corresponding values are present and valid.

- [ ] **Step 1: Write failing build-output tests**

```js
assert.match(html, /googletagmanager\.com\/gtag\/js\?id=G-TEST123456/);
assert.match(html, /<meta name="google-site-verification" content="token-123">/);
assert.doesNotMatch(htmlWithoutValues, /googletagmanager\.com|google-site-verification/);
```

- [ ] **Step 2: Run the test to verify it fails**

Run: `node --test test/contact-api.test.cjs`

Expected: FAIL because the generated HTML has no configurable GA4 or Search Console markup.

- [ ] **Step 3: Implement minimal configuration helpers in `build.mjs`**

```js
const ga4Id = /^G-[A-Z0-9]+$/.test(process.env.GA4_MEASUREMENT_ID || '')
  ? process.env.GA4_MEASUREMENT_ID : '';
const gscToken = (process.env.GSC_VERIFICATION_TOKEN || '').trim();
const analyticsHead = ga4Id
  ? `<script async src="https://www.googletagmanager.com/gtag/js?id=${ga4Id}"></script><script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date());gtag('config','${ga4Id}');</script>`
  : '';
const searchConsoleHead = gscToken
  ? `<meta name="google-site-verification" content="${escapeHtml(gscToken)}">`
  : '';
```

Insert `analyticsHead` and `searchConsoleHead` in `page()` before `</head>`, and add empty `GA4_MEASUREMENT_ID` and `GSC_VERIFICATION_TOKEN` entries to `.env.example`.

- [ ] **Step 4: Run the test and build checks**

Run: `node --test test/contact-api.test.cjs; node build.mjs; node check.cjs; node build.mjs --docs`

Expected: all tests and integrity checks pass; no analytics markup appears until production variables exist.

- [ ] **Step 5: Commit**

```bash
git add build.mjs .env.example test/contact-api.test.cjs docs/
git commit -m "feat: add configurable GA4 and Search Console markup"
```

### Task 2: Configure Resend and Vercel production secrets

**Files:**
- Modify: Vercel project `adelaidecarpentryhub-com-au` Production environment variables
- Modify: Resend domain configuration for `adelaidecarpentryhub.com.au`

**Interfaces:**
- Consumes: a Resend Sending access API key and confirmed DNS records for `adelaidecarpentryhub.com.au`.
- Produces: `RESEND_API_KEY` and `RESEND_FROM_EMAIL` available to `api/contact.js` in the Production deployment.

- [ ] **Step 1: Verify sender domain in Resend**

Add `adelaidecarpentryhub.com.au` in Resend Domains, copy every required SPF/DKIM/MX record to the domain DNS provider, and wait for the provider state `Verified`.

- [ ] **Step 2: Create a least-privilege Resend API key**

Create an API key named `MEL ONE website` with `Sending access`, copy the generated `re_...` value exactly once, and store it only in Vercel.

- [ ] **Step 3: Save Vercel Production variables**

```text
RESEND_API_KEY = re_...
RESEND_FROM_EMAIL = MEL ONE <enquiries@adelaidecarpentryhub.com.au>
```

Set both values for the Production environment. Mark the API key as sensitive/encrypted if the Vercel interface provides the option.

- [ ] **Step 4: Redeploy and test delivery**

Redeploy the latest `main` deployment. Submit a new unique enquiry through `/contact/`, then verify: HTTP success in the browser, one successful send in Resend Emails, and one received message at `handymanfelix.au2026@outlook.com` with the visitor email as Reply-To.

### Task 3: Configure GA4 and Google Search Console

**Files:**
- Modify: Vercel project `adelaidecarpentryhub-com-au` Production environment variables
- Modify: Google Analytics 4 property and web data stream
- Modify: Google Search Console URL-prefix property

**Interfaces:**
- Consumes: a GA4 Measurement ID and a Search Console HTML verification token created in the owner’s Google account.
- Produces: GA4 page-view data, a verified Search Console property, and submitted sitemap coverage.

- [ ] **Step 1: Create or select the GA4 web data stream**

In Google Analytics, create/select a property for MEL ONE and a Web stream with URL `https://adelaidecarpentryhub.com.au`. Copy the Measurement ID in `G-XXXXXXXXXX` format.

- [ ] **Step 2: Save public build variables in Vercel Production**

```text
GA4_MEASUREMENT_ID = G-XXXXXXXXXX
GSC_VERIFICATION_TOKEN = token copied from Google’s HTML-tag verification method
```

Do not paste a full `<meta>` element into `GSC_VERIFICATION_TOKEN`; use only its `content` value.

- [ ] **Step 3: Deploy the configured build**

Redeploy the latest `main` commit after saving both values, then inspect production page source for exactly one GA4 loader and one Search Console verification meta tag.

- [ ] **Step 4: Verify the Google Search Console property**

Add the URL-prefix property `https://adelaidecarpentryhub.com.au/`, choose HTML tag verification, and click Verify after the deployment is live.

- [ ] **Step 5: Submit sitemap and validate GA4**

Submit `https://adelaidecarpentryhub.com.au/sitemap.xml` in Search Console. Open the production website in a new browser session and confirm the visit appears in GA4 Realtime.

### Task 4: Final production verification

**Files:**
- Verify: `api/contact.js`
- Verify: `build.mjs`
- Verify: `docs/contact/index.html`
- Verify: Vercel deployment and provider dashboards

**Interfaces:**
- Consumes: Tasks 1-3 outputs.
- Produces: verified production email, analytics, and search configuration.

- [ ] **Step 1: Run local regressions**

Run: `node --test test/contact-api.test.cjs; node --check api/contact.js; node build.mjs; node check.cjs; node build.mjs --docs`

Expected: all commands exit zero.

- [ ] **Step 2: Verify production contact route**

Submit a second distinct contact enquiry. Confirm the page success message, Vercel function invocation success, Resend delivered status, and Outlook receipt.

- [ ] **Step 3: Verify tracking and indexing setup**

Confirm GA4 Realtime reports the production visit, Search Console reports the URL-prefix property verified, and sitemap status is successful or processing without errors.

- [ ] **Step 4: Commit final source changes**

```bash
git add build.mjs .env.example test/contact-api.test.cjs docs/
git commit -m "chore: prepare MEL ONE measurement and search verification"
git push origin main
```
