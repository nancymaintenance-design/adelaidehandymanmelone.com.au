# Codex Live Avatar Phase 1 Asset and Material Baseline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Recover the selected character's source textures, create one semantically organized Blender work file with Godot-compatible PBR materials, and prove that one GLB imports successfully into Blender and Godot 4.7.2 without creating replacement character models.

**Architecture:** A small Python pipeline discovers and audits the newest 3DMigoto capture, hashes and classifies DDS resources, then drives Blender in background mode to create review images, organize the existing meshes, build materials, and export one Phase 1 GLB candidate. A minimal Godot project performs a headless import smoke test. Binary assets remain under `D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1`; the repository stores only scripts, tests, manifests without copyrighted texture payloads, and documentation.

**Tech Stack:** Python 3 standard library, Blender 4.2 LTS Python API, 3DMigoto Frame Analysis, glTF 2.0/GLB, Godot 4.7.2 Standard x86_64, PowerShell, `unittest`.

**Spec:** `docs/superpowers/specs/2026-09-19-codex-live-avatar-godot-design.md`

## Global Constraints

- The existing body, face, outfit, and confirmed hair mesh are the only geometry baseline.
- Do not generate batches of replacement models or alternate character candidates.
- Create only one Phase 1 Blender work file and one Phase 1 GLB candidate, plus verification files.
- Recapture only missing textures, parts, expression references, or rest-pose evidence.
- Preserve original mesh data, UVs, custom normals, object boundaries, and the validated hair placement.
- The final target is Godot 4.x desktop; Phase 1 pins verification to Godot 4.7.2 Stable Standard x86_64.
- Do not treat the 576-joint capture rig or the four-skin SDK128 rig as the final Humanoid skeleton.
- Do not commit captured textures or extracted game binary assets to Git.

## Review Focus

- A capture directory with no DDS files must stop with an actionable `TEXTURE_CAPTURE_REQUIRED` result and must not create an empty material work file; Task 1 tests this.
- `share_dupes` hard links or repeated resource hashes must produce one review image per unique content hash while preserving every draw/slot provenance entry; Task 2 tests this.
- A malformed or unsupported DDS header must be reported in the inventory and skipped without aborting valid resources; Task 2 tests this.
- An ambiguous texture role must remain `needs_review` and must never be silently connected as Base Color, Normal, or Alpha; Task 5 tests this.
- Hair alpha and two-sided behavior must survive GLB export and Blender/Godot re-import without opaque rectangular hair cards; Tasks 5–7 test this.

---

## Planned File Structure

```text
avatar_pipeline/
├─ __init__.py
├─ config.py                     fixed paths, shader IDs, output policy
├─ capture_manifest.py           capture discovery and provenance manifest
├─ dds_inventory.py              DDS header parser, hash dedupe, slot inventory
├─ propose_material_roles.py     evidence-based role suggestions
├─ glb_audit.py                  reusable GLB JSON audit
├─ blender_build_texture_review.py
├─ blender_prepare_phase1_asset.py
├─ blender_apply_phase1_materials.py
├─ blender_export_phase1_glb.py
└─ blender_verify_phase1_glb.py
avatar_pipeline/config/
├─ mesh_roles.json               stable object grouping from validated draw IDs
└─ material_mapping.json         reviewed DDS-to-PBR assignments
tests/
├─ test_capture_manifest.py
├─ test_dds_inventory.py
├─ test_material_roles.py
└─ test_glb_audit.py
godot_phase1/
├─ project.godot
├─ phase1_import_check.gd
└─ assets/.gitkeep
```

Generated files remain outside Git:

```text
D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\
├─ capture_manifest.json
├─ texture_inventory.json
├─ texture_review\
├─ DOAXVV_phase1_material_work.blend
├─ DOAXVV_phase1_material.glb
├─ DOAXVV_phase1_roundtrip.blend
├─ phase1_glb_audit.json
└─ godot_import_report.json
```

## Scope Decomposition

This plan implements only the independently testable asset-and-material baseline. The approved design's remaining subsystems will receive separate plans after this phase passes: Phase 2 single Humanoid skeleton and skinning; Phase 3 facial topology, ARKit shapes, and visemes; Phase 4 animation and secondary motion; Phase 5 Godot runtime controllers and external API; Phase 6 performance and stability acceptance.

### Task 1: Discover and Gate the Texture Capture

**Files:**
- Create: `avatar_pipeline/__init__.py`
- Create: `avatar_pipeline/config.py`
- Create: `avatar_pipeline/capture_manifest.py`
- Create: `tests/test_capture_manifest.py`

**Interfaces:**
- Consumes: `Path` to the DOAXVV game root.
- Produces: `discover_latest_capture(game_root: Path, require_dds: bool = True) -> CaptureSummary` and `write_capture_manifest(summary: CaptureSummary, target: Path) -> None`.

- [ ] **Step 1: Write the capture discovery tests**

```python
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from avatar_pipeline.capture_manifest import CaptureRequired, discover_latest_capture


class CaptureManifestTests(unittest.TestCase):
    def test_newest_capture_with_dds_wins(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            older = root / "FrameAnalysis-2026-09-18-191648"
            newer = root / "FrameAnalysis-2026-09-19-101500"
            older.mkdir()
            newer.mkdir()
            (newer / "000307-ps-t0=hair.dds").write_bytes(b"DDS ")
            summary = discover_latest_capture(root)
            self.assertEqual(summary.path, newer)
            self.assertEqual(summary.dds_count, 1)

    def test_no_dds_raises_actionable_gate(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "FrameAnalysis-2026-09-18-191648").mkdir()
            with self.assertRaisesRegex(CaptureRequired, "TEXTURE_CAPTURE_REQUIRED"):
                discover_latest_capture(root)
```

- [ ] **Step 2: Run the tests and verify they fail**

Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest tests.test_capture_manifest -v
```

Expected: import failure for `avatar_pipeline.capture_manifest`.

- [ ] **Step 3: Implement the capture manifest**

Use these fixed constants in `avatar_pipeline/config.py`:

```python
GAME_ROOT = Path(r"D:\workbuddy\Steam\steamapps\common\DOAX-VenusVacation")
OUTPUT_ROOT = Path(r"D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1")
BLENDER = Path(r"D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe")
SOURCE_BLEND = Path(r"D:\DOAXVV-Tools\Output\DOAXVV_character_with_hair_fixed.blend")
TARGET_PIXEL_SHADERS = {
    "hair": "aeddebfe92d2e902",
    "face_body": "3f36f4a9b69e89bd",
    "outfit": "6f619bc773470686",
    "outfit_special": "2c82229c2b5c5eae",
}
```

`discover_latest_capture()` must sort valid `FrameAnalysis-YYYY-MM-DD-HHMMSS` directories by the timestamp encoded in their names, count DDS recursively, and raise `CaptureRequired("TEXTURE_CAPTURE_REQUIRED: enter the selected character scene and press F8 once")` when none contain DDS.

- [ ] **Step 4: Run the tests and write the real manifest**

Run the unittest command from Step 2, then:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m avatar_pipeline.capture_manifest
```

Expected before the user captures textures: exit code 2 and the exact `TEXTURE_CAPTURE_REQUIRED` message. Expected after one valid F8 capture: `capture_manifest.json` contains the selected capture path, DDS count, total bytes, and modification time.

- [ ] **Step 5: Commit the discovery gate**

```powershell
git add avatar_pipeline/__init__.py avatar_pipeline/config.py avatar_pipeline/capture_manifest.py tests/test_capture_manifest.py
git commit -m "feat: gate avatar pipeline on texture capture"
```

### Task 2: Inventory, Validate, and Deduplicate DDS Resources

**Files:**
- Create: `avatar_pipeline/dds_inventory.py`
- Create: `tests/test_dds_inventory.py`

**Interfaces:**
- Consumes: capture path from `capture_manifest.json`.
- Produces: `read_dds_header(path: Path) -> DDSInfo`, `build_texture_inventory(capture: Path) -> TextureInventory`, and `texture_inventory.json`.

- [ ] **Step 1: Write DDS parsing and dedupe tests**

```python
import struct
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from avatar_pipeline.dds_inventory import build_texture_inventory, read_dds_header


def minimal_dds(width: int, height: int) -> bytes:
    header = bytearray(128)
    header[:4] = b"DDS "
    struct.pack_into("<I", header, 4, 124)
    struct.pack_into("<I", header, 12, height)
    struct.pack_into("<I", header, 16, width)
    return bytes(header)


class DDSInventoryTests(unittest.TestCase):
    def test_reads_dimensions(self):
        with TemporaryDirectory() as tmp:
            path = Path(tmp) / "000307-ps-t0=abc.dds"
            path.write_bytes(minimal_dds(1024, 2048))
            info = read_dds_header(path)
            self.assertEqual((info.width, info.height), (1024, 2048))

    def test_hash_dedupe_preserves_provenance(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            payload = minimal_dds(512, 512)
            (root / "000306-ps-t0=abc.dds").write_bytes(payload)
            (root / "000307-ps-t0=abc.dds").write_bytes(payload)
            inventory = build_texture_inventory(root)
            self.assertEqual(len(inventory.resources), 1)
            self.assertEqual(len(inventory.resources[0].uses), 2)

    def test_malformed_dds_is_reported_without_hiding_valid_files(self):
        with TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "000307-ps-t0=valid.dds").write_bytes(minimal_dds(256, 256))
            (root / "000307-ps-t1=broken.dds").write_bytes(b"broken")
            inventory = build_texture_inventory(root)
            self.assertEqual(len(inventory.resources), 1)
            self.assertEqual(len(inventory.errors), 1)
```

- [ ] **Step 2: Run tests and verify failure**

Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest tests.test_dds_inventory -v
```

Expected: import failure for `avatar_pipeline.dds_inventory`.

- [ ] **Step 3: Implement strict DDS inventory**

Parse the DDS magic, 124-byte legacy header, width, height, FourCC, optional DX10 header, file length, SHA-256, draw number, shader stage, texture slot, resource hash, and absolute path. Group byte-identical resources by SHA-256 and retain a `uses` array for every filename/provenance occurrence. Record malformed resources in `errors` with path and reason.

- [ ] **Step 4: Run tests and inventory the real capture**

Run the unittest command from Step 2, then:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m avatar_pipeline.dds_inventory
```

Expected: all tests pass; `texture_inventory.json` contains at least one unique valid DDS and no unreported file failures.

- [ ] **Step 5: Commit the DDS inventory**

```powershell
git add avatar_pipeline/dds_inventory.py tests/test_dds_inventory.py
git commit -m "feat: inventory captured DDS resources"
```

### Task 3: Produce a Unique Texture Review Set

**Files:**
- Create: `avatar_pipeline/blender_build_texture_review.py`
- Create: `avatar_pipeline/run_texture_review.ps1`
- Modify: `avatar_pipeline/dds_inventory.py`
- Test: `tests/test_dds_inventory.py`

**Interfaces:**
- Consumes: `texture_inventory.json` and unique DDS paths.
- Produces: one PNG per unique valid DDS, `texture_review/index.json`, and contact sheets grouped by shader role and texture slot.

- [ ] **Step 1: Extend the inventory test for deterministic review filenames**

```python
def test_review_name_is_content_addressed(self):
    resource = make_resource(sha256="a" * 64, slot="ps-t0", width=512, height=512)
    self.assertEqual(resource.review_name, f"{'a' * 16}_ps-t0_512x512.png")
```

- [ ] **Step 2: Run the test and verify it fails**

Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest tests.test_dds_inventory.DDSInventoryTests.test_review_name_is_content_addressed -v
```

Expected: failure because `review_name` is missing.

- [ ] **Step 3: Implement review conversion and indexing**

`blender_build_texture_review.py` must open each unique DDS with `bpy.data.images.load`, preserve alpha, save a PNG no larger than 1024 pixels on either axis, and report failures without deleting the source. `run_texture_review.ps1` must invoke the pinned Blender executable and then create contact sheets from the converted PNGs. The index must map each PNG back to every draw number, shader hash, texture slot, source path, dimensions, format, and SHA-256.

- [ ] **Step 4: Run tests and build the review set**

Run all DDS tests, then:

```powershell
powershell -ExecutionPolicy Bypass -File avatar_pipeline/run_texture_review.ps1
```

Expected: `texture_review/index.json` has one successful entry per convertible unique DDS; duplicate DDS files do not create duplicate PNGs.

- [ ] **Step 5: Inspect all contact sheets and commit the review pipeline**

Confirm that color maps, normal maps, grayscale masks, eye textures, and hair alpha can be distinguished. Commit only scripts and tests:

```powershell
git add avatar_pipeline/blender_build_texture_review.py avatar_pipeline/run_texture_review.ps1 avatar_pipeline/dds_inventory.py tests/test_dds_inventory.py
git commit -m "feat: build texture review sheets"
```

### Task 4: Create One Non-Destructive Semantic Blender Work File

**Files:**
- Create: `avatar_pipeline/config/mesh_roles.json`
- Create: `avatar_pipeline/blender_prepare_phase1_asset.py`
- Create: `avatar_pipeline/blender_verify_phase1_asset.py`

**Interfaces:**
- Consumes: `D:\DOAXVV-Tools\Output\DOAXVV_character_with_hair_fixed.blend`.
- Produces: `D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\DOAXVV_phase1_material_work.blend` and an audit JSON printed to stdout.

- [ ] **Step 1: Record the validated initial mesh grouping**

Create `mesh_roles.json` with these non-destructive working groups:

```json
{
  "Hair": ["Hair_Main"],
  "HeadParts": ["000308", "000309", "000310", "000311", "000312"],
  "BodyBase": ["000313"],
  "OutfitParts": ["000326", "000327", "000328", "000329", "000330", "000331", "000332", "000333", "000334", "000335", "000336", "000337", "000338", "000339", "000340", "000341", "000342", "000343", "000344", "000345", "000346"],
  "AccessoryParts": ["000347", "000348"]
}
```

These labels describe working collections, not final anatomical claims. Preserve original object names in a `capture_object_name` custom property and give objects stable names such as `HeadPart_000311`.

- [ ] **Step 2: Implement the semantic work-file builder**

The Blender script must open the existing validated source, create collections matching the JSON keys, move each existing object without duplicating its mesh data, preserve modifiers/UVs/custom normals/vertex groups, set a `capture_draw` custom property, and save exactly one work file. It must fail if an expected object prefix is missing or if an unlisted character mesh remains.

- [ ] **Step 3: Implement the Blender verifier**

The verifier must exit nonzero unless all of the following hold:

```text
mesh_count = 30
hair_mesh_count = 1
hair_vertex_count = 7281
collections = Hair, HeadParts, BodyBase, OutfitParts, AccessoryParts
missing_capture_object_name = 0
duplicate_mesh_datablocks = 0
```

- [ ] **Step 4: Build and verify the work file**

Run:

```powershell
& 'D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe' --background --python avatar_pipeline/blender_prepare_phase1_asset.py
& 'D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe' --background --python avatar_pipeline/blender_verify_phase1_asset.py -- --source 'D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\DOAXVV_phase1_material_work.blend'
```

Expected: both commands exit 0 and the verifier reports the exact counts above.

- [ ] **Step 5: Commit the semantic preparation scripts**

```powershell
git add avatar_pipeline/config/mesh_roles.json avatar_pipeline/blender_prepare_phase1_asset.py avatar_pipeline/blender_verify_phase1_asset.py
git commit -m "feat: organize avatar meshes semantically"
```

### Task 5: Review Texture Roles and Build Godot-Compatible PBR Materials

**Files:**
- Create: `avatar_pipeline/propose_material_roles.py`
- Create: `avatar_pipeline/config/material_mapping.json`
- Create: `avatar_pipeline/blender_apply_phase1_materials.py`
- Create: `tests/test_material_roles.py`

**Interfaces:**
- Consumes: `texture_inventory.json`, `texture_review/index.json`, reviewed texture roles, and the Phase 1 work file.
- Produces: reviewed `material_mapping.json` and materials embedded in `DOAXVV_phase1_material_work.blend`.

- [ ] **Step 1: Write role-safety tests**

```python
import unittest
from avatar_pipeline.propose_material_roles import propose_role


class MaterialRoleTests(unittest.TestCase):
    def test_unknown_slot_stays_needs_review(self):
        result = propose_role(slot="ps-t7", channel_stats=None, filename="unknown.dds")
        self.assertEqual(result.status, "needs_review")
        self.assertIsNone(result.role)

    def test_normal_map_requires_normal_evidence(self):
        result = propose_role(slot="ps-t1", channel_stats={"blue_mean": 0.51, "rg_variance": 0.45}, filename="map.dds")
        self.assertNotEqual(result.role, "normal")
```

- [ ] **Step 2: Run tests and verify failure**

Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest tests.test_material_roles -v
```

Expected: import failure for `avatar_pipeline.propose_material_roles`.

- [ ] **Step 3: Implement conservative role proposals**

The proposer may use slot, shader group, dimensions, alpha presence, and contact-sheet channel statistics, but must emit `needs_review` whenever evidence conflicts. Use this typed mapping contract:

```python
@dataclass(frozen=True)
class MaterialMapping:
    name: str
    base_color_sha256: str
    normal_sha256: str | None
    orm_sha256: str | None
    alpha_source: str | None
    alpha_mode: Literal["OPAQUE", "MASK", "BLEND", "HASHED"]
    object_prefixes: tuple[str, ...]
```

`material_mapping.json` must contain `Hair`, `Skin`, `Eyes`, and `Outfit` records using the exact 64-character hashes selected from the review index. The validator must reject missing hashes, hashes absent from the inventory, invalid alpha modes, empty object-prefix lists, and any nonempty `unresolved` array before Blender is allowed to apply materials.

- [ ] **Step 4: Review and lock the mapping**

Inspect every contact sheet. For each role, record the exact SHA-256 and every target object prefix. Do not assign a map based on slot number alone. Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m avatar_pipeline.propose_material_roles --validate avatar_pipeline/config/material_mapping.json
```

Expected: exit 0, no unresolved resources used by character draws, and every referenced hash exists in the inventory.

- [ ] **Step 5: Apply materials in Blender**

Create Principled BSDF materials with Base Color images in sRGB and Normal/ORM images in Non-Color mode. Connect hair Base Color alpha to Principled Alpha, set hashed transparency and disable backface culling only for the hair material. Keep skin and opaque outfit pieces backface culled. Save into the same Phase 1 work file; do not create another character model.

- [ ] **Step 6: Verify material state**

Extend `blender_verify_phase1_asset.py` to fail unless:

```text
material_count >= 4
packed_or_resolved_images >= 4
missing_images = 0
Hair material alpha mode = HASHED
Hair material backface culling = disabled
Skin material alpha mode = OPAQUE
```

Render front, profile, back, and face-close previews and visually confirm scalp coverage, hair alpha, eye placement, skin seams, and outfit texture orientation.

- [ ] **Step 7: Commit the material pipeline and reviewed mapping**

```powershell
git add avatar_pipeline/propose_material_roles.py avatar_pipeline/config/material_mapping.json avatar_pipeline/blender_apply_phase1_materials.py avatar_pipeline/blender_verify_phase1_asset.py tests/test_material_roles.py
git commit -m "feat: restore avatar PBR materials"
```

### Task 6: Export and Round-Trip Audit the Phase 1 GLB

**Files:**
- Create: `avatar_pipeline/glb_audit.py`
- Create: `avatar_pipeline/blender_export_phase1_glb.py`
- Create: `avatar_pipeline/blender_verify_phase1_glb.py`
- Create: `tests/test_glb_audit.py`

**Interfaces:**
- Consumes: verified Phase 1 Blender work file.
- Produces: `DOAXVV_phase1_material.glb`, `DOAXVV_phase1_roundtrip.blend`, and `phase1_glb_audit.json`.

- [ ] **Step 1: Write a GLB audit regression test**

```python
import unittest
from avatar_pipeline.glb_audit import validate_phase1


class GLBAuditTests(unittest.TestCase):
    def test_rejects_textureless_candidate(self):
        audit = {"meshes": 30, "materials": 4, "textures": 0, "images": 0, "hair_present": True}
        with self.assertRaisesRegex(ValueError, "textures"):
            validate_phase1(audit)
```

- [ ] **Step 2: Run the test and verify failure**

Run:

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest tests.test_glb_audit -v
```

Expected: import failure for `avatar_pipeline.glb_audit`.

- [ ] **Step 3: Implement export and structural audit**

Export selected Mesh and Armature objects as GLB with skins enabled, animations disabled for Phase 1, Y-up enabled, materials included, and image data embedded. The audit must parse the GLB JSON chunk and require:

```text
meshes = 30
primitives = 30
materials >= 4
textures >= 4
images >= 4
hair_present = true
animations = 0
morph_targets = 0
```

The zero animation and morph-target counts are expected in Phase 1 and must be reported rather than treated as final-project completion.

- [ ] **Step 4: Export, re-import, and render verification views**

Run:

```powershell
& 'D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe' --background --python avatar_pipeline/blender_export_phase1_glb.py
& 'D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe' --background --python avatar_pipeline/blender_verify_phase1_glb.py
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m avatar_pipeline.glb_audit 'D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\DOAXVV_phase1_material.glb'
```

Expected: all commands exit 0; the round-trip file contains hair and all 30 meshes; front/profile/back/close previews show the same texture orientation and transparency as the source work file.

- [ ] **Step 5: Commit GLB export and audit tooling**

```powershell
git add avatar_pipeline/glb_audit.py avatar_pipeline/blender_export_phase1_glb.py avatar_pipeline/blender_verify_phase1_glb.py tests/test_glb_audit.py
git commit -m "feat: verify phase one avatar GLB"
```

### Task 7: Install Godot 4.7.2 Portable and Run an Import Smoke Test

**Files:**
- Create: `godot_phase1/project.godot`
- Create: `godot_phase1/phase1_import_check.gd`
- Create: `godot_phase1/assets/.gitkeep`
- Create: `avatar_pipeline/run_godot_phase1_check.ps1`

**Interfaces:**
- Consumes: `DOAXVV_phase1_material.glb`.
- Produces: Godot import cache and `godot_import_report.json` confirming that the scene, meshes, materials, textures, and hair load.

- [ ] **Step 1: Install the pinned portable editor**

Download the official Standard x86_64 archive from:

```text
https://godot-releases.nbg1.your-objectstorage.com/4.7.2-stable/Godot_v4.7.2-stable_win64.exe.zip
```

Extract it to `D:\DOAXVV-Tools\Godot-4.7.2`. Verify the executable reports `4.7.2.stable` before continuing. Do not install the preview 4.8 build.

- [ ] **Step 2: Create the minimal import project and checker**

`project.godot` must select the Forward+ renderer and define `res://phase1_import_check.gd` as the main scene script entry. The checker must load `res://assets/DOAXVV_phase1_material.glb`, instantiate it, traverse all descendants, and write a JSON report containing MeshInstance3D count, material count, texture-bearing material count, Skeleton3D count, and whether a node name contains `Hair`.

- [ ] **Step 3: Implement the PowerShell runner**

The runner must copy the single candidate GLB into `godot_phase1/assets`, launch Godot headlessly once to import it, run the checker, copy `godot_import_report.json` to the Phase 1 output directory, and remove only the copied project asset after the report is secured. It must not delete `.godot` import metadata during the same run.

- [ ] **Step 4: Run the Godot smoke test**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File avatar_pipeline/run_godot_phase1_check.ps1
```

Expected report:

```json
{
  "loaded": true,
  "mesh_instances": 30,
  "materials": 4,
  "materials_with_textures": 4,
  "skeletons": 1,
  "hair_present": true
}
```

The Skeleton3D count validates import only; Phase 2 replaces the capture rig with the single standard Humanoid skeleton.

- [ ] **Step 5: Commit the Godot smoke-test project**

```powershell
git add godot_phase1/project.godot godot_phase1/phase1_import_check.gd godot_phase1/assets/.gitkeep avatar_pipeline/run_godot_phase1_check.ps1
git commit -m "test: smoke test avatar import in Godot"
```

### Task 8: Record Phase 1 Evidence and Gate Phase 2

**Files:**
- Modify: `E:\Ellis\02-治理\Codex-Live-Avatar\01-当前上下文.md`
- Modify: `E:\Ellis\02-治理\Codex-Live-Avatar\03-资产与工具清单.md`
- Modify: `E:\Ellis\02-治理\Codex-Live-Avatar\05-实施路线图.md`
- Modify: `E:\Ellis\02-治理\Codex-Live-Avatar\07-工作日志.md`

**Interfaces:**
- Consumes: capture, DDS, Blender, GLB, and Godot audit reports.
- Produces: a durable Phase 1 record and a clear Phase 2 entry condition.

- [ ] **Step 1: Run the full Phase 1 verification suite**

```powershell
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m unittest discover -s tests -p 'test_*.py' -v
& 'D:\DOAXVV-Tools\Blender-4.2-LTS\blender-4.2.19-windows-x64\blender.exe' --background --python avatar_pipeline/blender_verify_phase1_asset.py -- --source 'D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\DOAXVV_phase1_material_work.blend'
& 'C:\Users\UFTR\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' -m avatar_pipeline.glb_audit 'D:\DOAXVV-Tools\Output\CodexLiveAvatar\phase1\DOAXVV_phase1_material.glb'
powershell -ExecutionPolicy Bypass -File avatar_pipeline/run_godot_phase1_check.ps1
```

Expected: zero test failures and every validator exits 0.

- [ ] **Step 2: Inspect the final evidence**

Open the front, profile, back, and face-close preview images. Confirm no opaque hair cards, missing scalp coverage, flipped textures, obvious UV seams, new geometry distortion, or missing character parts.

- [ ] **Step 3: Update Obsidian with measured results**

Record the exact capture directory, unique DDS count, material names, GLB byte size, Godot 4.7.2 import counts, preview paths, unresolved visual defects, and the SHA-256 of the Phase 1 GLB. Mark Phase 1 complete only when all automated and visual checks pass.

- [ ] **Step 4: Commit the implementation state**

```powershell
git status --short
git log --oneline --decorate -10
```

Commit only source, test, configuration, and documentation files. Confirm that no DDS, extracted texture, `.blend`, or `.glb` file is staged.

- [ ] **Step 5: Gate Phase 2**

Phase 2 standard-Humanoid work may start only when the Godot import report has `loaded: true`, hair is present with working alpha, the body/eyes/outfit have reviewed materials, and the Phase 1 GLB checksum is recorded in Obsidian.
