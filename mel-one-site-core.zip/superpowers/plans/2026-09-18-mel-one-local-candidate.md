# MEL ONE Local Candidate Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the legacy carpentry candidate with an original, local-only MEL ONE household-maintenance website candidate and a runnable local preview.

**Architecture:** Retain the existing dependency-free Node static generator, but replace its content model, route matrix, templates, styles, schemas and checks with a fact-ledger-driven MEL ONE model. Public route data and JSON-LD originate from the same approved records; local management uses browser-local persistence and never contacts external systems.

**Tech Stack:** Node.js 22+, static HTML generator, vanilla CSS/JS, Node test runner, local `serve.cjs` preview.

**Spec:** `docs/superpowers/specs/2026-09-18-mel-one-handyman-local-candidate-design.md`

## Global Constraints

- Local-only: no deployment, external API calls, email sending, telemetry or account changes.
- Only user-confirmed contact details are public.
- No fabricated reviews, ratings, credentials, cases, pricing, guarantees or hidden SEO content.
- Regulated/evidence-dependent service records remain draft/noindex until explicitly approved.
- All structured data mirrors visible, approved content.

---

### Task 1: Freeze MEL ONE content, asset and route contracts

**Files:**
- Create: `src/content-pack/mel-one-site-content.json`
- Create: `tests/mel-one-content.test.cjs`
- Modify: `build.mjs`

**Interfaces:**
- Produces validated public records `{site, services, news, guides, faqs}` with `status`, `slug`, `title`, `description`, `scope` and `exclusions`.
- Consumed by generator, metadata, schemas, sitemap and local admin.

- [ ] Write failing tests asserting user-confirmed contacts, no Review/AggregateRating data, unique approved slugs and exclusion of draft routes from sitemap.
- [ ] Run `node --test tests/mel-one-content.test.cjs` and confirm expected contract failure.
- [ ] Implement the JSON content contract and generator import.
- [ ] Re-run the targeted test, then `npm test`.

### Task 2: Build the MEL ONE frontstage and responsive visual system

**Files:**
- Create: `src/assets/mel-one-logo.png`
- Create: `src/assets/images/mel-one-home-field-notes-hero.png`
- Modify: `build.mjs`, `src/assets/css/*`, `src/assets/js/site.js`
- Test: `tests/mel-one-routes.test.cjs`

**Interfaces:**
- Consumes approved records from Task 1.
- Produces semantic routes, `tel:`/`mailto:` contact actions, visible service exclusions, 404 noindex, and responsive layouts.

- [ ] Write failing route tests for the required public routes, visible contact actions, logo use, 404 noindex and no legacy brand text.
- [ ] Run the targeted test and confirm expected failure.
- [ ] Copy the authorized logo, add an ImageGen conceptual hero asset, then implement the shared visual system and route templates.
- [ ] Re-run targeted tests, `npm test`, and `npm run build`.

### Task 3: Implement news, guides and local-only management

**Files:**
- Modify: `build.mjs`, `src/assets/js/site.js`, `src/assets/css/*`
- Create: `tests/mel-one-admin.test.cjs`

**Interfaces:**
- Consumes typed news/guide records and produces semantic Article pages.
- Admin persists approved editor fields only in browser-local storage and supports reset.

- [ ] Write failing tests for Article metadata/HTML and admin local-only disclosure hooks.
- [ ] Run the targeted test and confirm expected failure.
- [ ] Implement original editorial templates and the local management surface.
- [ ] Re-run targeted tests, `npm test`, and `npm run build`.

### Task 4: Implement technical SEO, crawl controls and local verification

**Files:**
- Modify: `build.mjs`, `tests/*`, `README.md`, `serve.cjs`
- Create: `tests/mel-one-seo.test.cjs`

**Interfaces:**
- Consumes the same public route records as Tasks 1–3.
- Produces metadata, canonical URLs, sitemap, robots, llms.txt and validated JSON-LD.

- [ ] Write failing tests for unique metadata, schema-visible-content constraints, sitemap/robots/llms.txt, no review markup and no legacy contact data.
- [ ] Run the targeted test and confirm expected failure.
- [ ] Implement the technical SEO outputs and local preview branding.
- [ ] Run `npm test`, `npm run build`, `npm run check`, local HTTP checks and visual/browser QA where available.
