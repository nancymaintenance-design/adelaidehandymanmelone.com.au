# MEL ONE Visual Refresh Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver the MEL ONE brand migration and a cohesive craft-led visual system without altering the existing homepage hero image.

**Architecture:** The content pack remains the source of truth for public copy. The static builder is extended to emit the MEL ONE mark and decorative-symbol hooks, while `theme.css` owns visual tokens and responsive component treatments. New artwork is copied alongside existing project assets by the builder.

**Tech Stack:** Node.js 22 static-site generator, HTML, CSS, built-in image generation.

**Spec:** `docs/superpowers/specs/2026-09-17-mel-one-visual-refresh-design.md`

## Global Constraints

- Public brand name and short mark are exactly `MEL ONE` and `MO`.
- Preserve `src/assets/hero-bg.jpg` byte-for-byte and retain its homepage use.
- Do not add runtime dependencies.
- Decorative artwork contains no text, no watermark, and does not convey essential information alone.
- Preserve existing routes, contact details, and local-brief behavior.

---

### Task 1: Add brand migration regression checks

**Files:**
- Modify: `check.cjs`

**Interfaces:**
- Consumes: built HTML in `public/`.
- Produces: checks named `MEL ONE brand is rendered` and `No Ellis/ESG branding remains`.

- [ ] **Step 1: Write the failing checks**

```js
all &= check('MEL ONE brand is rendered', home.includes('MEL ONE'));
all &= check('No Ellis/ESG branding remains', !/Ellis Services Group|>ESG</.test(home));
```

- [ ] **Step 2: Run the checker to verify it fails**

Run: `npm run build; npm run check`

Expected: the MEL ONE check fails because the initial generated homepage still contains `Ellis Services Group` and `ESG`.

- [ ] **Step 3: Keep the checks in the final checker**

Place them after the homepage checks, and rename the checker banner to `MEL ONE Website Integrity Check`.

- [ ] **Step 4: Re-run after Tasks 2–4**

Run: `npm run build; npm run check`

Expected: both brand checks pass.

### Task 2: Move source copy and builder output to MEL ONE

**Files:**
- Modify: `src/content-pack/site-content.json`
- Modify: `src/assets/asset-manifest.json`
- Modify: `build.mjs`

**Interfaces:**
- Consumes: `content.brand.name`, `content.brand.short_name`, and asset-manifest alt/caption text.
- Produces: MEL ONE wordmark, MO fallback initials, favicon, placeholder imagery label, JSON-LD publisher, and generated public copy.

- [ ] **Step 1: Make Task 1's brand check fail**

Run: `npm run build; npm run check`

Expected: `MEL ONE brand is rendered` fails before editing source data.

- [ ] **Step 2: Update source data**

Replace every company-name occurrence in the content pack and manifest with `MEL ONE`; set `brand.name` to `MEL ONE` and `brand.short_name` to `MO`. Preserve all service, location, contact, and claim text otherwise.

- [ ] **Step 3: Update generated chrome**

In `build.mjs`, derive the header initials from `content.brand.short_name`, use those initials in the fallback SVG and favicon, and replace hard-coded company-name strings with `brandName`. Add `symbolAsset(name)` returning `/assets/symbol-${name}.png` for the decorative hooks used in Task 4.

- [ ] **Step 4: Verify generated text**

Run: `npm run build; rg -n -i "Ellis Services Group|>ESG<" public`

Expected: build succeeds and ripgrep produces no matches.

### Task 3: Generate and ship original craft symbols

**Files:**
- Create: `src/assets/symbol-joint.png`
- Create: `src/assets/symbol-measure.png`
- Create: `src/assets/symbol-grain.png`
- Create: `src/assets/symbol-repair.png`
- Modify: `build.mjs`

**Interfaces:**
- Consumes: image assets from `src/assets/`.
- Produces: four `/assets/symbol-*.png` URLs in both `public/` and `docs/` output.

- [ ] **Step 1: Add a failing asset check**

Add this to `check.cjs`:

```js
for (const symbol of ['joint', 'measure', 'grain', 'repair']) {
  all &= check(`Symbol asset: ${symbol}`, fs.existsSync(path.join(root, 'assets', `symbol-${symbol}.png`)));
}
```

- [ ] **Step 2: Run checker to verify missing assets fail**

Run: `npm run build; npm run check`

Expected: all four symbol checks fail.

- [ ] **Step 3: Generate, inspect, and copy the artwork**

Generate four separate transparent-background PNGs in a single consistent editorial line-art style. Copy the selected final assets into `src/assets/` using the exact filenames above. Do not replace `hero-bg.jpg`.

- [ ] **Step 4: Copy symbols during build**

Append the four exact symbol filenames to the `imageFiles` array in `build.mjs`.

- [ ] **Step 5: Run checker to verify assets ship**

Run: `npm run build; npm run check; npm run build:docs`

Expected: all four symbol checks pass in `public/`, and `docs/assets/` contains all four PNGs.

### Task 4: Establish and apply the MEL ONE visual system

**Files:**
- Modify: `src/assets/base.css`
- Modify: `src/assets/theme.css`
- Modify: `build.mjs`

**Interfaces:**
- Consumes: four symbol asset URLs and generated semantic classes (`choice`, `service-card`, `method-step`, `value-card`, `details`).
- Produces: tokenized responsive styling; icon/media hooks emitted by the builder; visible keyboard focus, hover, and active states.

- [ ] **Step 1: Add a failing static style check**

Add this to `check.cjs`:

```js
const theme = fs.readFileSync(path.join(root, 'assets', 'theme.css'), 'utf8');
all &= check('MEL ONE visual tokens ship', theme.includes('--mel-forest') && theme.includes('--mel-copper'));
```

- [ ] **Step 2: Verify the style check fails**

Run: `npm run build; npm run check`

Expected: `MEL ONE visual tokens ship` fails before the new visual system exists.

- [ ] **Step 3: Implement tokenized styles and component treatments**

Define `--mel-forest`, `--mel-timber`, `--mel-copper`, and related surface/line tokens. Restyle header, nav, buttons, cards, fields, accordions, footer, and responsive layout as described in the spec. Use symbol artwork in service, process, values, FAQ, and closing-section ornamentation with CSS backgrounds or generated `<img alt="">` elements. Add `:focus-visible`, `:hover`, and `:active` states without changing navigation or form logic.

- [ ] **Step 4: Update builder hooks**

Add decorative, empty-alt symbol images to the service cards, process steps, and value cards using `symbolAsset()` and map by index. Do not inject symbols into homepage hero media.

- [ ] **Step 5: Build and verify checks**

Run: `npm run build; npm run check; npm run build:docs`

Expected: all checks pass and both output roots include the refreshed CSS, MEL ONE branding, and symbol images.

### Task 5: Verify generated website and source invariants

**Files:**
- Verify: `src/assets/hero-bg.jpg`
- Verify: `public/index.html`
- Verify: `public/services/index.html`
- Verify: `public/about/index.html`
- Verify: `public/contact/index.html`
- Verify: `public/services/house-framing/index.html`

**Interfaces:**
- Consumes: built static output.
- Produces: recorded final verification outcome.

- [ ] **Step 1: Confirm hero source was preserved**

Run: `Get-FileHash src/assets/hero-bg.jpg -Algorithm SHA256`

Expected: compare this result with the hash captured before Task 3; the values are identical.

- [ ] **Step 2: Inspect pages in a browser**

Run: `npm run serve`

Inspect the listed pages at 1440px and 390px widths. Open one FAQ item, tab through header and contact form, and hover a service card and CTA.

Expected: navigation works; hover/focus remains perceptible; hero is unchanged; no icon has essential text; mobile nav has no overflow.

- [ ] **Step 3: Perform final source and output scans**

Run: `rg -n -i "Ellis Services Group|>ESG<" src build.mjs public docs; npm run check`

Expected: ripgrep exits with no matches and the integrity checker passes.

## Plan self-review

- Spec coverage: Task 2 covers branding and SEO/structured output; Task 3 covers original assets and build copying; Task 4 covers the visual system and component application; Task 5 covers hero preservation, responsive/accessibility inspection, and all required output checks.
- Placeholder scan: no incomplete implementation steps or undefined interfaces remain.
- Consistency: all assets use the same `symbol-<name>.png` naming and are emitted through `symbolAsset(name)`.
