# MEL ONE Gold Standard Visual Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transform the local MEL ONE candidate from an editorial minimal site into a high-impact household-maintenance conversion experience without weakening its verified-content or local-only guarantees.

**Architecture:** Keep `build.mjs` as the only public-page generator and `mel-one-site-content.json` as the only public content source. Replace the shared page shell and CSS visual system with a Gold Standard Home Care system, then add small semantic decorative components generated from local SVG/CSS and verify the completed site at desktop and mobile sizes.

**Tech Stack:** Node.js static generator, plain semantic HTML, local CSS/JS, Node test runner, local `serve.cjs` preview.

**Spec:** `docs/superpowers/specs/2026-09-18-mel-one-gold-standard-visual-redesign.md`

## Global Constraints

- Preserve `src/content-pack/mel-one-site-content.json` as the exclusive public-content source.
- Use only confirmed MEL ONE name, phone `0416 614 281`, email `admin@melonemaintenance.com.au` and address `63 Pirie St, Adelaide SA 5000`.
- Do not introduce reviews, ratings, credentials, prices, insurance, history, customer projects, analytics, external requests or live submissions.
- Plumbing and gas remain absent. Restricted work remains enquiry-only with case-by-case specialist coordination wording.
- Preserve 24 local pages plus schema, robots, sitemap and llms output. Do not deploy or change `api/contact.js`.
- Existing worktree is dirty/untracked; do not commit or reset unrelated files.

---

### Task 1: Durable Visual Context and Gold Token Contract

**Files:**
- Modify: `DESIGN.md`
- Modify: `tests/mel-one-seo.test.cjs`

**Interfaces:**
- Consumes: visual spec token names and existing generated home HTML.
- Produces: `DESIGN.md` token-to-CSS contract and test assertions for `gold-route`, `task-wall`, and `mobile-actions` elements.

- [ ] **Step 1: Write failing visual-contract assertions**

```js
assert.match(home, /class="gold-route"/);
assert.match(home, /class="task-wall"/);
assert.match(home, /class="mobile-actions"/);
```

- [ ] **Step 2: Run the focused test to verify it fails**

Run: `node --test tests/mel-one-seo.test.cjs`

Expected: FAIL because the existing generated home has no `gold-route` or `task-wall` class.

- [ ] **Step 3: Replace stale carpentry visual context**

Write `DESIGN.md` so it names Obsidian `#111714`, Workbench black `#202823`, Crown gold `#F7B733`, Ember orange `#E9642B`, Eucalyptus `#718576` and Limestone `#F3EFE5`; map each token to CSS custom properties; document the roof-line, task-wall, responsive dock, focus and reduced-motion behavior.

- [ ] **Step 4: Run the focused test after Tasks 2 and 3 land**

Run: `pnpm test`

Expected: all repository tests pass; assertions prove the generator emits the documented visual signatures.

### Task 2: High-Impact Shared Shell and Hero

**Files:**
- Modify: `build.mjs`
- Modify: `src/assets/css/site.css`
- Test: `tests/mel-one-routes.test.cjs`

**Interfaces:**
- Consumes: `site`, `contact`, `hero`, `canonical(route)`, `actions()` and approved content records in `build.mjs`.
- Produces: `<div class="gold-route" aria-hidden="true">`, `<section class="hero-stage">`, and visual-first `page()` HTML used by every public route.

- [ ] **Step 1: Write a failing shared-shell assertion**

```js
assert.match(home, /class="hero-stage"/);
assert.match(home, /class="gold-route" aria-hidden="true"/);
assert.match(home, /Call 0416 614 281/);
```

- [ ] **Step 2: Run it to verify it fails**

Run: `node --test tests/mel-one-routes.test.cjs`

Expected: FAIL because the prior shell has `home-hero` and no roof-route markup.

- [ ] **Step 3: Implement semantic hero structure**

In the home `page()` call, replace the current hero wrapper with a `hero-stage` containing the existing heading, existing image and two existing actions. Insert a decorative inline SVG with `class="gold-route"`, `aria-hidden="true"`, `focusable="false"`, and a path that visually continues into later sections. Keep the image’s existing truthful concept-image alt text.

- [ ] **Step 4: Implement shared visual shell CSS**

Replace `site.css` tokens and hero rules with the six documented tokens. Use a dark, layered hero surface, gold route glow, high-contrast action buttons, image framing, responsive CSS grid and a `prefers-reduced-motion` branch that disables route animation. Keep `:focus-visible` and do not load remote font or image URLs.

- [ ] **Step 5: Run focused tests**

Run: `node --test tests/mel-one-routes.test.cjs tests/mel-one-seo.test.cjs`

Expected: PASS with approved contacts, local-only form behavior, hero classes and existing crawl guards preserved.

### Task 3: Nine-Category Task Wall and Conversion Surfaces

**Files:**
- Modify: `build.mjs`
- Modify: `src/assets/css/site.css`
- Modify: `src/assets/js/site.js`
- Test: `tests/mel-one-seo.test.cjs`

**Interfaces:**
- Consumes: `published.services`, each with `title`, `description`, `slug`, `scope` and `exclusions`.
- Produces: `serviceTaskWall(records)` returning `<section class="task-wall">`; responsive `.mobile-actions` with local anchor and `tel:` controls.

- [ ] **Step 1: Add a failing task-wall test**

```js
const serviceLinks = home.match(/href="\/services\//g) || [];
assert.ok(serviceLinks.length >= 9);
assert.match(home, /class="task-wall"/);
assert.doesNotMatch(home, /plumbing|gas/i);
```

- [ ] **Step 2: Run it to verify it fails**

Run: `node --test tests/mel-one-seo.test.cjs`

Expected: FAIL because the old uniform `card-grid` has no task-wall class.

- [ ] **Step 3: Create `serviceTaskWall(records)` inside `build.mjs`**

Implement a helper that maps each approved service to an `<article class="task-card task-card--N">` with a simple local inline icon, service title, description, up to three escaped `scope` items, and its existing detail link. Call it on home and services collection page; preserve all service detail routes and schemas.

- [ ] **Step 4: Style the task-wall and conversion bands**

Implement asymmetric grid spans for desktop, a readable single-column stack for narrow viewports, visible hover/focus treatments and no motion when reduced motion is selected. Add a visual enquiry band that reuses current truthful scope/availability copy and current action hrefs.

- [ ] **Step 5: Keep menu and enquiry interactions keyboard-safe**

Retain menu Escape/focus restoration and form local-preview behavior in `site.js`. Add only decorative-class toggles if needed; never add `fetch`, `XMLHttpRequest`, `sendBeacon`, persistence APIs or form submission endpoints.

- [ ] **Step 6: Run focused tests**

Run: `node --test tests/mel-one-content.test.cjs tests/mel-one-routes.test.cjs tests/mel-one-seo.test.cjs`

Expected: PASS; the content, no-legacy, no-network and mobile action tests remain green.

### Task 4: Visual Verification and Release Gate

**Files:**
- Modify: `premium-audit.json`
- Test: `test/*.test.cjs`, `tests/*.test.cjs`

**Interfaces:**
- Consumes: generated `public/`, `DESIGN.md`, browser local preview and `frontend-design-premium` audit command.
- Produces: current audit record that refers to MEL ONE files only and a browser-verified local preview.

- [ ] **Step 1: Build the candidate**

Run: `pnpm build`

Expected: output reports 24 generated pages and no old generated assets remain.

- [ ] **Step 2: Run all contract tests**

Run: `pnpm test`

Expected: every test passes. If sandbox blocks Node test workers, rerun the exact command with approved local execution and record the sandbox limitation separately.

- [ ] **Step 3: Run premium static audit**

Run: `python C:\Users\UFTR\.codex\plugins\cache\openai-curated-remote\frontend-design-premium\1.4.0\skills\frontend-design-premium\scripts\audit_project.py E:\EllisWebsite-GitHub --mode strict`

Expected: write current findings to `premium-audit.json`; resolve findings that concern active MEL ONE source/public files. Do not treat stale source directories as evidence of the candidate.

- [ ] **Step 4: Verify local desktop and mobile behavior in browser**

Open: `http://127.0.0.1:5173/`

Check: hero image and logo render, roof-line is decorative, nine service links appear, Call and Start an enquiry are visible at 390px, menu Escape behavior works, contact form reports local preview without network activity, and reduced-motion has no essential animated-only content.

- [ ] **Step 5: Record completion without deployment**

Report: touched files, test/build/audit/browser results, local preview URL and the remaining boundary that a real domain and message backend require separate authorization.

## Self-Review

- Spec coverage: Task 1 updates durable design context; Task 2 provides hero/shell; Task 3 provides task wall and conversion behavior; Task 4 runs visual, technical and local-only gates.
- Placeholder scan: no `TBD`, `TODO` or “similar to” instructions remain.
- Interface check: Task 3 consumes the `published.services` record shape already defined in the content contract; it does not add a new content source or API.
